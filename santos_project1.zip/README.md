# IGME430_Project1
Creating a repository for my first IGME 430 project
